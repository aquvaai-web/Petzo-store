PETLY SHOPIFY MVP

1. In Shopify Admin, create a product:
   Name: Petly Smart Tag
   Price: ₹299
   Handle: petly-smart-tag
   Add your product images if desired.

2. Go to Online Store > Themes > Add theme > Upload ZIP.
   Upload petly-shopify-theme.zip.

3. Open Customize and make sure the product handle is petly-smart-tag.

4. Orders:
   Shopify automatically records orders and can email your store's order-notification address.
   Set/check it under Settings > Notifications > Staff order notifications.

5. For testing, keep payment as a method you can actually accept in India.
   Shopify's checkout/payment availability depends on your Shopify setup and country.

The included poster is your uploaded Petly poster and is used in the storefront.
